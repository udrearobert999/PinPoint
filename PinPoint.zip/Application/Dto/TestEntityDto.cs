﻿namespace Application.Dto;

public class TestEntityDto
{
    public string Name { get; set; } = null!;
}
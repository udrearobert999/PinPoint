﻿namespace Application.Dto
{
    public class AboutDto
    {
        public string Title { get; set; }
    }
}